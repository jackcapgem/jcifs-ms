# spring-batch-intro

This is a small demo using Spring Batch to read from a csv file and write to a database and vice-versa.

Run the docker-compose file and run the project ;)

More details: https://aboullaite.me/spring-batch-tutorial-with-spring-boot/
